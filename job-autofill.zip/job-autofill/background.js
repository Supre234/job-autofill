// Relays "run" requests to every frame of the active tab.
function sendRun(tabId, mode) {
  chrome.tabs.sendMessage(tabId, { type: "jaf-run", mode }).catch(() => {});
}

chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd !== "run-autofill") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) sendRun(tab.id, "auto");
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "jaf-relay" && sender.tab) {
    sendRun(sender.tab.id, msg.mode);
  } else if (msg.type === "jaf-relay-stop" && sender.tab) {
    chrome.tabs.sendMessage(sender.tab.id, { type: "jaf-stop" }).catch(() => {});
  } else if (msg.type === "jaf-relay-tab" && msg.tabId) {
    // from popup
    if (msg.action === "stop") chrome.tabs.sendMessage(msg.tabId, { type: "jaf-stop" }).catch(() => {});
    else sendRun(msg.tabId, msg.mode);
  } else if (msg.type === "jaf-open-options") {
    chrome.runtime.openOptionsPage();
  }
  sendResponse && sendResponse({ ok: true });
});
