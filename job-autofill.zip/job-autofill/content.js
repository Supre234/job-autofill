(() => {
  if (window.__jafLoaded) return;
  window.__jafLoaded = true;

  const IS_TOP = window.top === window;
  const RUN_KEY = "jaf_running";
  const MAX_STEPS = 12;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) => (s || "").replace(/\*/g, " ").replace(/\s+/g, " ").trim().toLowerCase();

  let profile = null, resume = null, coverLetter = null, stopFlag = false, running = false;

  // ---------------------------------------------------------------- rules
  // Order matters: more specific rules first.
  const FIELD_RULES = [
    ["phoneCode", /country\s*(phone\s*)?code|phone\s*(number\s*)?code|dial(l)?ing\s*code/],
    ["_mobile", /phone\s*(device\s*)?type/],
    ["firstName", /first\s*name|given\s*name|forename|\bfname\b/],
    ["lastName", /last\s*name|sur\s*name|family\s*name|\blname\b/],
    ["email", /e-?mail/],
    ["phone", /phone|mobile|contact\s*(no|number)|telephone|\bcell\b/],
    ["linkedin", /linked\s*in/],
    ["github", /git\s*hub/],
    ["portfolio", /portfolio|website|personal\s*(site|url)|\bblog\b|\burl\b/],
    ["currentCTC", /current\s*(ctc|salary|compensation|package|remuneration)|present\s*(ctc|salary)|\bcctc\b/],
    ["expectedCTC", /expected\s*(ctc|salary|compensation|package)|salary\s*expectation|desired\s*(salary|compensation)|\bectc\b/],
    ["noticePeriod", /notice\s*period|how\s*soon.*(join|start)|days.*notice|when\s*can\s*you\s*(join|start)/],
    ["relevantExperience", /relevant\s*(work\s*)?experience/],
    ["totalExperience", /(total|overall)\s*(work\s*)?experience|years?\s*of\s*(total\s*|work\s*|professional\s*)?experience|experience\s*\(?\s*in\s*years|how\s*many\s*years|\bexperience\b/],
    ["currentCompany", /current\s*(company|employer|organi[sz]ation)|present\s*(company|employer)|employer\s*name|company\s*name|\bemployer\b|\bcompany\b/],
    ["currentTitle", /current\s*(job\s*)?(title|designation|role|position)|job\s*title|\bdesignation\b|\bposition\s*title\b/],
    ["fieldOfStudy", /field\s*of\s*study|\bmajor\b|specialisation|specialization|discipline|\bbranch\b|\bstream\b/],
    ["university", /universit|college|\bschool\b|institution|institute/],
    ["degree", /\bdegree\b|qualification|education\s*level|highest\s*education/],
    ["gradYear", /graduation\s*year|year\s*of\s*(passing|graduation)|passing\s*year|graduated/],
    ["gpa", /\bgpa\b|\bcgpa\b|percentage|\bgrade\b/],
    ["zip", /\bzip\b|postal|pin\s*code|pincode/],
    ["state", /\bstate\b|province|\bregion\b/],
    ["city", /\bcity\b|\btown\b/],
    ["country", /\bcountry\b|nationality/],
    ["address", /address|street/],
    ["location", /location|where.*(based|located|live)/],
    ["startDate", /start\s*date|available\s*(from|date)|earliest.*start|date\s*available/],
    ["hearAbout", /how\s*did\s*you\s*(hear|find|learn)|where\s*did\s*you\s*(hear|find)|\bsource\b|referral\s*source/],
    ["skills", /\bskills?\b|technologies|tech\s*stack/],
    ["summary", /cover\s*letter|summary|about\s*(you|yourself)|why.*(join|want|interested|apply|fit)|additional\s*information|tell\s*us/],
    ["fullName", /full\s*name|^name$|^your\s*name$|candidate\s*name|legal\s*name|^name\b/],
  ];

  // Yes/No style screening questions → profile key
  const QUESTION_RULES = [
    ["needSponsorship", /sponsor/],
    ["workAuth", /authori[sz]ed\s*to\s*work|legally\s*(authori[sz]ed|eligible|permitted)|right\s*to\s*work|eligible\s*to\s*work|work\s*permit|work\s*authori[sz]ation/],
    ["willRelocate", /relocat/],
    ["previouslyWorked", /previously\s*(worked|employed|applied)|former\s*(employee|intern)|ever\s*(worked|been\s*employed)/],
    ["_yes", /(at least|over|above)\s*18|legal\s*age|comfortable\s*(with|working)|willing\s*to\s*(travel|work|commute)|able\s*to\s*(commute|work|travel|perform)|background\s*check|drug\s*(test|screen)/],
    ["gender", /\bgender\b|\bsex\b/],
    ["veteran", /veteran|military/],
    ["disability", /disabilit/],
    ["race", /\brace\b|ethnic/],
  ];

  const CONSENT_RE = /agree|consent|acknowledge|terms|privacy|certify|declare|accurate|i\s*understand|data\s*processing/;
  const SKIP_CHECKBOX_RE = /currently\s*(work|study)|newsletter|marketing|promotion|subscribe|sms|text\s*message|updates/;

  // ---------------------------------------------------------------- helpers
  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const st = getComputedStyle(el);
    if (st.display === "none" || st.visibility === "hidden" || +st.opacity === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  const textOf = (n) => (n ? (n.innerText || n.textContent || "") : "");

  function primaryLabel(el) {
    const parts = [];
    const aria = el.getAttribute("aria-label"); if (aria) parts.push(aria);
    const lb = el.getAttribute("aria-labelledby");
    if (lb) lb.split(/\s+/).forEach((id) => { const n = document.getElementById(id); if (n) parts.push(textOf(n)); });
    if (el.labels) for (const l of el.labels) parts.push(textOf(l));
    if (el.id) { try { const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`); if (l) parts.push(textOf(l)); } catch (e) {} }
    const wrap = el.closest("label"); if (wrap) parts.push(textOf(wrap));
    if (el.placeholder) parts.push(el.placeholder);
    return norm(parts.join(" "));
  }
  function containerLabel(el) {
    let node = el.parentElement;
    for (let i = 0; i < 5 && node && node !== document.body; i++, node = node.parentElement) {
      const lab = node.querySelector("legend, label, [class*='label'], [class*='question'], [class*='title'], h3, h4");
      if (lab && !lab.contains(el)) { const t = norm(textOf(lab)); if (t && t.length < 300) return t; }
      if (lab && lab.contains(el)) {
        const clone = lab.cloneNode(true); clone.querySelectorAll("input,select,textarea").forEach((x) => x.remove());
        const t = norm(clone.textContent); if (t && t.length < 300) return t;
      }
    }
    return "";
  }
  function attrLabel(el) {
    const tids = [];
    for (let n = el, i = 0; n && i < 10; n = n.parentElement, i++) { const t = n.getAttribute && n.getAttribute("data-testid"); if (t && !/^(field|select-|screen-reader|VStack|input-undefined)/.test(t)) tids.push(t); }
    return norm([el.name, el.id, el.getAttribute("data-automation-id"), el.getAttribute("data-qa"), el.getAttribute("autocomplete"), ...tids].filter(Boolean).join(" ").replace(/[_\-.\[\]]/g, " "));
  }
  function fullLabel(el) {
    const p = primaryLabel(el);
    return { primary: p, secondary: norm(containerLabel(el) + " " + attrLabel(el)) };
  }

  function nativeSet(el, v) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
      : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    el.focus();
    setter.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }
  function realClick(el) {
    el.scrollIntoView({ block: "center" });
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((t) =>
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
  }

  // ---------------------------------------------------------------- value resolution
  function computeValue(key) {
    const p = profile;
    switch (key) {
      case "fullName": return [p.firstName, p.lastName].filter(Boolean).join(" ");
      case "phone": return p.phone;
      case "_yes": return "Yes";
      case "_mobile": return "Mobile";
      default: return p[key];
    }
  }
  function matchRules(rules, text) {
    for (const [key, re] of rules) if (text && re.test(text)) return key;
    return null;
  }
  // Returns {key, value} or null
  function resolve(el, isChoice) {
    const { primary, secondary } = fullLabel(el);
    for (const t of [primary, secondary, primary + " " + secondary]) {
      if (!t) continue;
      for (const r of profile.customRules || []) if (t.includes(r.keyword)) return { key: "custom", value: r.answer };
    }
    const tryText = (t) => {
      if (!t) return null;
      const qk = matchRules(QUESTION_RULES, t);
      if (qk && (isChoice || t.length > 25 || qk === "gender" || qk === "race" || qk === "veteran" || qk === "disability")) {
        const v = computeValue(qk); if (v) return { key: qk, value: v };
      }
      const fk = matchRules(FIELD_RULES, t);
      if (fk) { const v = computeValue(fk); if (v) return { key: fk, value: v }; }
      return null;
    };
    return tryText(primary) || tryText(secondary) || null;
  }

  function pickOption(options, answer) {
    const a = norm(answer); if (!a) return null;
    const t = (o) => norm(o.text);
    const usable = options.filter((o) => t(o) && !/^(select|choose|--|please select)/.test(t(o)));
    if (/^(yes|y|true)$/.test(a)) return usable.find((o) => /^yes\b/.test(t(o))) || null;
    if (/^(no|n|false)$/.test(a)) return usable.find((o) => /^no\b/.test(t(o))) || usable.find((o) => /\bnot\b|\bdon'?t\b/.test(t(o))) || null;
    if (/^\d+(\.\d+)?$/.test(a)) {
      const n = parseFloat(a);
      for (const o of usable) {
        const s = t(o); let m;
        if ((m = s.match(/(\d+(?:\.\d+)?)\s*(?:-|to|–)\s*(\d+(?:\.\d+)?)/)) && n >= +m[1] && n <= +m[2]) return o;
        if ((m = s.match(/(\d+(?:\.\d+)?)\s*\+|(?:more than|over|above)\s*(\d+(?:\.\d+)?)/)) && n >= +(m[1] || m[2])) return o;
      }
    }
    return usable.find((o) => t(o) === a) || usable.find((o) => t(o).startsWith(a))
      || usable.find((o) => t(o).includes(a)) || usable.find((o) => t(o).length > 2 && a.includes(t(o))) || null;
  }

  // ---------------------------------------------------------------- fillers
  function fillText(el, res) {
    let v = String(res.value);
    if (el.type === "number") v = v.replace(/[^\d.]/g, "");
    if (el.type === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
    if (el.type === "tel" && res.key === "phone" && profile.phoneCode && el.maxLength > 0 && el.maxLength < 14) { /* keep national number */ }
    if (!v) return false;
    nativeSet(el, v);
    return true;
  }
  function fillSelect(el, res) {
    const opts = [...el.options].map((o) => ({ el: o, text: o.textContent }));
    const hit = pickOption(opts, res.value);
    if (!hit) return false;
    nativeSet(el, hit.el.value);
    return true;
  }
  async function fillCombobox(el, res) {
    // type-ahead style (react-select, Workday search, Greenhouse location, etc.)
    const term = res.key === "location" ? String(res.value).split(",")[0].trim() : String(res.value);
    nativeSet(el, term);
    await sleep(900);
    const list = [...document.querySelectorAll('[role="option"], [role="listbox"] li, ul[class*="option"] li, [class*="option"][class*="select"]')].filter(isVisible);
    const hit = pickOption(list.map((o) => ({ el: o, text: textOf(o) })), res.value) || (list.length ? { el: list[0] } : null);
    if (hit) { realClick(hit.el); await sleep(200); return true; }
    el.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    return true;
  }
  const isWdMulti = (el) => !!(el.closest && el.closest('[data-automation-id="multiSelectContainer"]')) || el.getAttribute("data-automation-id") === "searchBox";
  const enterKey = (el, type) => el.dispatchEvent(new KeyboardEvent(type, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
  function wdChips(el) {
    const c = el.closest('[data-automation-id="multiSelectContainer"]') || el.parentElement;
    return norm([...c.querySelectorAll('[data-automation-id="selectedItem"], [data-automation-id="selectedItemList"] li')].map(textOf).join(" "));
  }
  async function fillWorkdayMulti(el, res) {
    // Workday search-select: type, press Enter, then click the matching prompt option (may be hierarchical).
    const term = res.key === "phoneCode" ? (profile.country || "India") : String(res.value);
    const optSel = '[data-automation-id="promptOption"], [data-automation-id="menuItem"], [role="option"]';
    const visibleOpts = () => [...document.querySelectorAll(optSel)].filter(isVisible)
      .map((o) => ({ el: o, text: o.getAttribute("data-automation-label") || textOf(o) }));
    realClick(el); await sleep(250);
    nativeSet(el, term); await sleep(500);
    enterKey(el, "keydown"); enterKey(el, "keypress"); enterKey(el, "keyup");
    await sleep(1200);
    for (let round = 0; round < 3; round++) {
      const opts = visibleOpts();
      if (!opts.length) break;
      const hit = pickOption(opts, res.value) || pickOption(opts, term) || (round === 0 ? opts[0] : null);
      if (!hit) break;
      realClick(hit.el); await sleep(700);
      if (wdChips(el)) break;        // chip appeared: selection done
    }
    if (el.value) { nativeSet(el, ""); }   // never leave search text behind
    return !!wdChips(el);
  }
  async function fillListboxButton(btn, res) {
    // Workday-style dropdown: <button aria-haspopup="listbox">
    realClick(btn); await sleep(500);
    const list = [...document.querySelectorAll('[role="option"], [role="listbox"] li')].filter(isVisible);
    const hit = pickOption(list.map((o) => ({ el: o, text: textOf(o) })), res.value);
    if (hit) { realClick(hit.el); await sleep(250); return true; }
    document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    return false;
  }
  function radioGroupQuestion(radios) {
    const first = radios[0];
    const fs = first.closest("fieldset, [role='radiogroup'], [role='group']");
    let q = "";
    if (fs) {
      const lg = fs.querySelector("legend");
      q = norm(textOf(lg)) || norm(textOf(document.getElementById(fs.getAttribute("aria-labelledby") || "")));
      if (!q) q = norm(fs.getAttribute("aria-label"));
    }
    if (!q) q = containerLabel(first);
    return q;
  }
  function radioLabelText(r) {
    return norm(primaryLabel(r)) || norm(textOf(r.parentElement));
  }

  async function fillGroupedChoices(scope, stats) {
    // radios
    const groups = {};
    scope.querySelectorAll('input[type="radio"]').forEach((r) => {
      if (r.disabled) return;
      (groups[r.name || r.id || Math.random()] ||= []).push(r);
    });
    for (const radios of Object.values(groups)) {
      if (!radios.some(isVisible) && !radios.some((r) => isVisible(r.parentElement))) continue;
      if (radios.some((r) => r.checked) && !profile.overwrite) continue;
      const q = radioGroupQuestion(radios);
      const fake = { getAttribute: () => null };
      let ans = null;
      for (const r of profile.customRules || []) if (q.includes(r.keyword)) ans = r.answer;
      if (!ans) { const k = matchRules(QUESTION_RULES, q); if (k) ans = computeValue(k); }
      if (!ans) continue;
      const hit = pickOption(radios.map((r) => ({ el: r, text: radioLabelText(r) })), ans);
      if (hit) {
        const lab = hit.el.labels && hit.el.labels[0];
        realClick(lab || hit.el); if (!hit.el.checked) realClick(hit.el);
        stats.filled++; await sleep(80);
      } else stats.skipped.push(q.slice(0, 60));
    }
    // checkboxes (consent only)
    if (profile.autoConsent !== false) {
      scope.querySelectorAll('input[type="checkbox"]').forEach((c) => {
        if (c.checked || c.disabled || !(isVisible(c) || isVisible(c.parentElement))) return;
        const t = norm(primaryLabel(c) + " " + containerLabel(c));
        if (CONSENT_RE.test(t) && !SKIP_CHECKBOX_RE.test(t)) { realClick(c.labels && c.labels[0] ? c.labels[0] : c); if (!c.checked) realClick(c); stats.filled++; }
      });
    }
  }

  async function fillFiles(scope, stats) {
    if (!resume && !coverLetter) return;
    const inputs = [...scope.querySelectorAll('input[type="file"]')].filter((i) => !i.disabled);
    for (const inp of inputs) {
      if (inp.files && inp.files.length && !profile.overwrite) continue;
      const { primary, secondary } = fullLabel(inp);
      const t = primary + " " + secondary;
      const isCover = /cover\s*letter/.test(t);
      let doc = null;
      if (isCover) doc = coverLetter;                                   // cover letter inputs get the cover letter only
      else if (/photo|picture|portfolio|transcript|certificate|id\s*proof/.test(t) && !/resume|cv/.test(t)) doc = null;
      else if (inputs.length > 1 && !/resume|cv/.test(t)) doc = null;
      else doc = resume;                                                // "Resume" and "CV" both get the resume
      if (!doc) continue;
      try {
        const blob = await (await fetch(doc.data)).blob();
        const file = new File([blob], doc.name, { type: doc.type });
        const dt = new DataTransfer(); dt.items.add(file);
        inp.files = dt.files;
        inp.dispatchEvent(new Event("input", { bubbles: true }));
        inp.dispatchEvent(new Event("change", { bubbles: true }));
        stats.filled++; await sleep(400);
      } catch (e) { stats.skipped.push(isCover ? "cover letter upload" : "resume upload"); }
    }
  }

  // ---------------------------------------------------------------- one step
  function stepScope() {
    // Prefer an open modal (LinkedIn Easy Apply etc.), else whole document.
    const modal = [...document.querySelectorAll('[role="dialog"], [aria-modal="true"], .artdeco-modal')].filter(isVisible)
      .find((m) => m.querySelector("input, select, textarea"));
    return modal || document;
  }
  function visibleFields(scope) {
    return [...scope.querySelectorAll("input, select, textarea, button[aria-haspopup='listbox']")].filter((el) => {
      if (el.matches('input[type="hidden"], input[type="submit"], input[type="button"], input[type="image"], input[type="reset"], input[type="search"]')) return false;
      if (el.matches('input[type="radio"], input[type="checkbox"], input[type="file"]')) return false;
      if (el.disabled || el.readOnly) return false;
      return isVisible(el);
    });
  }
  function fingerprint(scope) {
    const f = [...scope.querySelectorAll("input, select, textarea")].filter((e) => e.type !== "hidden" && isVisible(e) || e.type === "file");
    return location.pathname + "|" + f.length + "|" + f.map((e) => (e.name || e.id || "") + e.type).join(",").slice(0, 400)
      + "|" + norm(textOf(scope.querySelector && scope.querySelector("h1,h2,h3"))).slice(0, 60);
  }

  async function fillStep() {
    const stats = { filled: 0, skipped: [] };
    const scope = stepScope();
    // Upload resume first: many ATSs (Rippling, Workday) parse it and auto-fill other fields asynchronously.
    const before = stats.filled;
    await fillFiles(scope, stats);
    if (stats.filled > before) await sleep(3500);
    for (const el of visibleFields(scope)) {
      if (stopFlag) break;
      try {
        const isSelect = el.tagName === "SELECT";
        const isListbtn = el.tagName === "BUTTON";
        const isCombo = el.getAttribute("role") === "combobox" || el.getAttribute("aria-autocomplete") === "list" || el.getAttribute("aria-haspopup") === "listbox";
        // already has value?
        const wd = !isSelect && !isListbtn && isWdMulti(el);
        let current = isListbtn ? norm(textOf(el)) : wd ? wdChips(el) : (el.value || "");
        if (isSelect) { const o = el.selectedOptions[0]; current = o && o.value && !/^(select|choose|please)/i.test(o.textContent.trim()) ? o.textContent : ""; }
        if (isListbtn && /select one|^select$|choose/.test(current)) current = "";
        const res = resolve(el, isSelect || isListbtn);
        const wrongCode = res && res.key === "phoneCode" && !norm(current).includes(norm(res.value));
        if (String(current).trim() && !profile.overwrite && !wrongCode) continue;
        if (!res) { if (el.required || el.getAttribute("aria-required") === "true") stats.skipped.push(fullLabel(el).primary.slice(0, 60) || attrLabel(el)); continue; }

        let ok = false;
        if (isSelect) ok = fillSelect(el, res);
        else if (isListbtn) ok = await fillListboxButton(el, res);
        else if (wd) ok = await fillWorkdayMulti(el, res);
        else if (isCombo && !["tel", "number", "date"].includes(el.type)) ok = await fillCombobox(el, res);
        else ok = fillText(el, res);
        if (ok) stats.filled++; else stats.skipped.push(fullLabel(el).primary.slice(0, 60));
        await sleep(60);
      } catch (e) { console.warn("[JobAutofill] field error", e); }
    }
    await fillGroupedChoices(scope, stats);
    return stats;
  }

  function emptyRequired(scope) {
    const out = [];
    scope.querySelectorAll("input, select, textarea").forEach((el) => {
      if (!isVisible(el) || el.disabled || el.type === "hidden" || el.type === "file") return;
      const req = el.required || el.getAttribute("aria-required") === "true";
      if (!req) return;
      if (el.type === "radio") { if (!scope.querySelector(`input[type="radio"][name="${CSS.escape(el.name)}"]:checked`)) out.push(el); return; }
      if (el.type === "checkbox") { if (!el.checked) out.push(el); return; }
      if (isWdMulti(el) && wdChips(el)) return;
      if (!String(el.value || "").trim()) out.push(el);
    });
    return [...new Set(out)];
  }
  function highlight(els) {
    els.forEach((e) => { e.style.outline = "2px solid #ef4444"; e.style.outlineOffset = "2px"; });
    if (els[0]) els[0].scrollIntoView({ block: "center", behavior: "smooth" });
  }

  // ---------------------------------------------------------------- navigation
  const NEXT_SELECTORS = [
    '[data-automation-id="bottom-navigation-next-button"]', '[data-automation-id="pageFooterNextButton"]',
    'button[aria-label*="Continue to next step" i]', 'button[aria-label*="Review your application" i]',
  ];
  const NEXT_RE = /^(save\s*(&|and)\s*(continue|next)|next(\s*step|\s*page)?|continue(\s*to\s*\w+)?|proceed|review|review\s*(&|and)\s*continue|go\s*to\s*next.*|continue\s*application|next\s*>|save\s*&\s*next)$/;
  const FINAL_RE = /submit|finish|send\s*application|complete\s*application|confirm\s*and\s*apply|apply\s*now$|^apply$/;
  const APPLY_RE = /^(easy\s*apply|apply(\s*now)?|apply\s*for\s*(this\s*)?(job|role|position)|apply\s*manually|i'?m\s*interested|start\s*application|apply\s*with.*manually)$/;

  function clickables() {
    return [...document.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"], a.btn, a[class*="button"], a[class*="apply"]')]
      .filter((b) => isVisible(b) && !b.disabled && b.getAttribute("aria-disabled") !== "true");
  }
  const btnText = (b) => norm(b.value || b.getAttribute("aria-label") || textOf(b));

  function findNext() {
    for (const s of NEXT_SELECTORS) { const b = [...document.querySelectorAll(s)].find(isVisible); if (b) return b; }
    const scope = stepScope();
    const all = clickables().filter((b) => scope === document || scope.contains(b));
    return all.find((b) => NEXT_RE.test(btnText(b))) || null;
  }
  function findFinal() {
    const scope = stepScope();
    return clickables().filter((b) => scope === document || scope.contains(b)).find((b) => FINAL_RE.test(btnText(b))) || null;
  }
  function findApply() {
    return clickables().find((b) => APPLY_RE.test(btnText(b))) || null;
  }

  async function waitForChange(before, scopeBefore) {
    const start = Date.now();
    while (Date.now() - start < 9000) {
      await sleep(350);
      if (fingerprint(stepScope()) !== before) { await sleep(900); return true; }
    }
    return false;
  }

  // ---------------------------------------------------------------- UI
  let toastEl;
  function toast(msg, kind) {
    if (!IS_TOP && !document.body) return;
    if (!toastEl) {
      toastEl = document.createElement("div");
      Object.assign(toastEl.style, { position: "fixed", right: "16px", bottom: "70px", zIndex: 2147483647, maxWidth: "340px",
        padding: "10px 14px", borderRadius: "8px", font: "13px/1.4 system-ui,sans-serif", color: "#fff", boxShadow: "0 4px 14px rgba(0,0,0,.3)" });
      document.documentElement.appendChild(toastEl);
    }
    toastEl.style.background = kind === "error" ? "#dc2626" : kind === "ok" ? "#059669" : "#2563eb";
    toastEl.textContent = "Job Autofill: " + msg;
    toastEl.style.display = "block";
    clearTimeout(toastEl._t);
    if (kind !== "busy") toastEl._t = setTimeout(() => (toastEl.style.display = "none"), 9000);
  }
  function injectButton() {
    if (!IS_TOP) return;
    const b = document.createElement("button");
    b.textContent = "⚡ Autofill";
    b.title = "Fill this application and continue (Alt+Shift+F)";
    Object.assign(b.style, { position: "fixed", right: "16px", bottom: "16px", zIndex: 2147483646, padding: "9px 14px",
      border: "0", borderRadius: "999px", background: "#2563eb", color: "#fff", font: "600 13px system-ui,sans-serif",
      cursor: "pointer", boxShadow: "0 4px 14px rgba(0,0,0,.3)", opacity: ".85" });
    b.onmouseenter = () => (b.style.opacity = "1"); b.onmouseleave = () => (b.style.opacity = ".85");
    b.onclick = () => {
      if (running) { chrome.runtime.sendMessage({ type: "jaf-relay-stop" }); b.textContent = "⚡ Autofill"; }
      else { chrome.runtime.sendMessage({ type: "jaf-relay", mode: "auto" }); }
    };
    document.documentElement.appendChild(b);
    window.__jafBtn = b;
  }

  // ---------------------------------------------------------------- main loop
  async function loadData() {
    const d = await chrome.storage.local.get(["profile", "resume", "coverLetter"]);
    profile = d.profile; resume = d.resume; coverLetter = d.coverLetter;
    return !!(profile && (profile.firstName || profile.email));
  }

  async function run(mode) {
    if (running) return;
    running = true; stopFlag = false;
    if (window.__jafBtn) window.__jafBtn.textContent = "■ Stop";
    try {
      if (!(await loadData())) {
        if (IS_TOP) { toast("No profile saved yet. Opening the profile page…", "error"); chrome.runtime.sendMessage({ type: "jaf-open-options" }); }
        return;
      }
      sessionStorage.setItem(RUN_KEY, mode === "auto" ? "1" : "");

      let acted = false, steps = 0, idleSteps = 0;
      while (steps++ < MAX_STEPS && !stopFlag) {
        const scope = stepScope();
        const fields = visibleFields(scope);
        const hasChoices = scope.querySelector('input[type="radio"], input[type="file"]');

        // Form not open yet → try Apply button
        if (fields.length < 2 && !hasChoices) {
          const ap = profile.autoApply !== false && !acted && findApply();
          if (ap) { toast("Opening application…", "busy"); const fp = fingerprint(scope); realClick(ap); await waitForChange(fp); acted = true; continue; }
          if (!acted && !IS_TOP) return;            // empty sub-frame: stay quiet
          if (!acted) { toast("No application form found on this page. Open the job's apply form first.", "error"); return; }
        }

        toast(`Filling step ${steps}…`, "busy");
        const stats = await fillStep();
        acted = true;
        if (stopFlag) break;

        const missing = emptyRequired(stepScope());
        if (missing.length) {
          highlight(missing);
          toast(`Step ${steps}: filled ${stats.filled}. ${missing.length} required field(s) need you (highlighted). Fix them, then press Autofill again to continue.`, "error");
          return;
        }
        if (mode === "step") { toast(`Filled ${stats.filled} field(s) on this step.`, "ok"); return; }

        const next = findNext();
        if (!next) {
          const fin = findFinal();
          if (fin) { fin.scrollIntoView({ block: "center" }); fin.style.outline = "3px solid #059669"; toast("All steps filled. Review everything, then click Submit yourself.", "ok"); }
          else toast(`Filled ${stats.filled} field(s). No Next button found: review the form, solve any captcha, then submit yourself.`, "ok");
          sessionStorage.setItem(RUN_KEY, "");
          return;
        }
        const before = fingerprint(stepScope());
        toast(`Step ${steps} done (${stats.filled} filled). Going to next step…`, "busy");
        realClick(next);
        const changed = await waitForChange(before);
        if (!changed) {
          const bad = [...document.querySelectorAll('[aria-invalid="true"], input:invalid, select:invalid, textarea:invalid')].filter(isVisible);
          highlight(bad);
          toast(bad.length ? `The site rejected ${bad.length} field(s) (highlighted). Fix them and press Autofill again.` : "Next step didn't load. Check the page, then press Autofill again.", "error");
          return;
        }
        // If the page navigated fully this script restarts and resumes via RUN_KEY.
      }
      if (steps > MAX_STEPS) toast("Stopped after the maximum number of steps. Review the form.", "error");
      else if (stopFlag) toast("Stopped.", "ok");
    } catch (e) {
      console.error("[JobAutofill]", e);
      toast("Error: " + e.message, "error");
    } finally {
      running = false;
      sessionStorage.setItem(RUN_KEY, "");   // a full-page navigation kills this script before reaching here, so the flag survives only when needed
      if (window.__jafBtn) window.__jafBtn.textContent = "⚡ Autofill";
    }
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "jaf-run") run(msg.mode || "auto");
    if (msg.type === "jaf-stop") { stopFlag = true; sessionStorage.setItem(RUN_KEY, ""); }
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && running) { stopFlag = true; sessionStorage.setItem(RUN_KEY, ""); } });

  injectButton();
  // Resume after a full page navigation in the middle of an auto run.
  if (sessionStorage.getItem(RUN_KEY) === "1") setTimeout(() => run("auto"), 1800);
})();
