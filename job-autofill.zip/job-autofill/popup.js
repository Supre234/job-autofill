async function activeTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab && tab.id;
}
async function go(action, mode) {
  const tabId = await activeTabId();
  if (tabId) await chrome.runtime.sendMessage({ type: "jaf-relay-tab", tabId, action, mode });
  window.close();
}
document.getElementById("auto").onclick = () => go("run", "auto");
document.getElementById("step").onclick = () => go("run", "step");
document.getElementById("stop").onclick = () => go("stop");
document.getElementById("opts").onclick = () => { chrome.runtime.openOptionsPage(); window.close(); };
