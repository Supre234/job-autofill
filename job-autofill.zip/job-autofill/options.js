const YN = ["", "Yes", "No"];
const SECTIONS = [
  ["Personal", [
    ["firstName", "First name"], ["lastName", "Last name"],
    ["email", "Email", "email"], ["phone", "Phone (without country code)"],
    ["phoneCode", "Phone country code", "text", "+91"],
    ["gender", "Gender", ["", "Male", "Female", "Non-binary", "Prefer not to say"]],
  ]],
  ["Address", [
    ["address", "Street address"], ["city", "City"], ["state", "State / Province"],
    ["zip", "PIN / ZIP code"], ["country", "Country", "text", "India"],
    ["location", "Current location (e.g. Bengaluru, India)"],
  ]],
  ["Links", [
    ["linkedin", "LinkedIn URL"], ["github", "GitHub URL"], ["portfolio", "Portfolio / Website"],
  ]],
  ["Work", [
    ["currentCompany", "Current company"], ["currentTitle", "Current job title"],
    ["totalExperience", "Total experience (years)", "text", "e.g. 5"],
    ["relevantExperience", "Relevant experience (years)"],
    ["noticePeriod", "Notice period", "text", "e.g. 30 days"],
    ["currentCTC", "Current CTC / salary"], ["expectedCTC", "Expected CTC / salary"],
    ["startDate", "Earliest start date", "date"],
    ["skills", "Skills (comma separated)", "text", "", true],
    ["summary", "Cover letter / About you", "textarea", "", true],
  ]],
  ["Education", [
    ["degree", "Highest degree", "text", "Bachelor's / B.Tech"], ["fieldOfStudy", "Field of study"],
    ["university", "University / College"], ["gradYear", "Graduation year"], ["gpa", "CGPA / Percentage"],
  ]],
  ["Screening questions", [
    ["workAuth", "Authorized to work in the country applying?", YN, "Yes"],
    ["needSponsorship", "Require visa sponsorship?", YN, "No"],
    ["willRelocate", "Willing to relocate?", YN, "Yes"],
    ["previouslyWorked", "Previously worked at this company?", YN, "No"],
    ["hearAbout", "How did you hear about us?", "text", "LinkedIn"],
    ["veteran", "Veteran status", YN, "No"], ["disability", "Disability status", YN, "No"],
    ["race", "Race / Ethnicity (optional)", "text", ""],
  ]],
];
const DEFAULTS = {
  workAuth: "Yes", needSponsorship: "No", willRelocate: "Yes", previouslyWorked: "No",
  hearAbout: "LinkedIn", veteran: "No", disability: "No", phoneCode: "+91", country: "India",
};

const root = document.getElementById("sections");
for (const [title, fields] of SECTIONS) {
  const h = document.createElement("h2"); h.textContent = title; root.appendChild(h);
  const grid = document.createElement("div"); grid.className = "grid"; root.appendChild(grid);
  for (const [key, label, type = "text", ph = "", full] of fields) {
    const wrap = document.createElement("label");
    const isSelect = Array.isArray(type);
    if (full || type === "textarea") wrap.className = "full";
    wrap.append(label);
    let input;
    if (isSelect) {
      input = document.createElement("select");
      for (const o of type) { const op = document.createElement("option"); op.value = o; op.textContent = o || "—"; input.appendChild(op); }
    } else if (type === "textarea") {
      input = document.createElement("textarea");
    } else {
      input = document.createElement("input"); input.type = type;
    }
    if (typeof ph === "string") input.placeholder = ph;
    input.id = "f_" + key; input.dataset.key = key;
    wrap.appendChild(input); grid.appendChild(wrap);
  }
}

const q = (id) => document.getElementById(id);
const allInputs = () => [...document.querySelectorAll("[data-key]")];

chrome.storage.local.get(["profile", "resume", "coverLetter"], ({ profile, resume, coverLetter }) => {
  const p = { ...DEFAULTS, ...(profile || {}) };
  for (const el of allInputs()) el.value = (profile && profile[el.dataset.key]) || DEFAULTS[el.dataset.key] || "";
  q("customRules").value = p.customRulesText || "";
  q("overwrite").checked = !!p.overwrite;
  q("autoConsent").checked = p.autoConsent !== false;
  q("autoApply").checked = p.autoApply !== false;
  if (resume) q("resumeName").textContent = "Saved: " + resume.name;
  if (coverLetter) q("coverName").textContent = "Saved: " + coverLetter.name;
});

q("resumeFile").addEventListener("change", (e) => {
  const f = e.target.files[0]; if (!f) return;
  if (f.size > 8 * 1024 * 1024) { alert("Resume must be under 8 MB."); return; }
  const r = new FileReader();
  r.onload = () => {
    chrome.storage.local.set({ resume: { name: f.name, type: f.type || "application/pdf", data: r.result } },
      () => { q("resumeName").textContent = "Saved: " + f.name; });
  };
  r.readAsDataURL(f);
});
q("clearResume").onclick = () => chrome.storage.local.remove("resume", () => { q("resumeName").textContent = ""; q("resumeFile").value = ""; });

q("save").onclick = () => {
  const profile = {};
  for (const el of allInputs()) profile[el.dataset.key] = el.value.trim();
  profile.customRulesText = q("customRules").value;
  profile.customRules = q("customRules").value.split("\n").map((l) => l.split("=>")).filter((a) => a.length >= 2 && a[0].trim())
    .map((a) => ({ keyword: a[0].trim().toLowerCase(), answer: a.slice(1).join("=>").trim() }));
  profile.overwrite = q("overwrite").checked;
  profile.autoConsent = q("autoConsent").checked;
  profile.autoApply = q("autoApply").checked;
  chrome.storage.local.set({ profile }, () => {
    q("status").textContent = "Saved ✓";
    setTimeout(() => (q("status").textContent = ""), 2000);
  });
};

q("coverFile").addEventListener("change", (e) => {
  const f = e.target.files[0]; if (!f) return;
  if (f.size > 8 * 1024 * 1024) { alert("Cover letter must be under 8 MB."); return; }
  const r = new FileReader();
  r.onload = () => {
    chrome.storage.local.set({ coverLetter: { name: f.name, type: f.type || "application/pdf", data: r.result } },
      () => { q("coverName").textContent = "Saved: " + f.name; });
  };
  r.readAsDataURL(f);
});
q("clearCover").onclick = () => chrome.storage.local.remove("coverLetter", () => { q("coverName").textContent = ""; q("coverFile").value = ""; });

q("clearAll").onclick = () => {
  if (!confirm("Delete your saved profile, resume and cover letter from this browser?")) return;
  chrome.storage.local.clear(() => location.reload());
};
